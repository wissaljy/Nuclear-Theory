import math

# G. Royer, Nucl. Phys. A 848, 279 (2010).
# URL: https://doi.org/10.1016/j.nuclphysa.2010.09.009

#====================================================================================================#
# Function to calculate Modified Royer Formula

def modified_royer(Z, N, A, Q, a, b, c, e, l):
    log_T = a * Z * Q**(-0.5) + b * A**(1/6) * Z**(1/2) + c + d * ((A * N * Z * (l * (l+1)))/(Q)) + e * A * (1-(-1)**l)
    T_MR = 10**log_T
    return log_T


def determine_parameters(Z, N):
    if Z % 2 == 0 and N % 2 == 0: # Z and N is even
        a = 1.58439
        b = -1.15847
        c = -25.319
        d = 0
        e = 0
    elif Z % 2 == 0 and N % 1 == 0: # Z is even and N is odd
        a = 1.61114
        b = -1.06904
        c = -27.8792
        d = 0.00000234
        e = 0.00064
    elif Z % 1 == 0 and N % 2 == 0: # Z is odd and N is even
        a = 1.63194
        b = -1.06471
        c = -28.6423
        d = 0.00000149
        e = 0.0018
    else: # N and Z are odd
        a = 1.63192
        b = -1.05756
        c = -28.618
        d = 0.00000190
        e = 0.0012
    return a, b, c, d, e

#====================================================================================================#
# Create and open an output text file for writing results
with open("output_results_MR.txt", "w") as output_file:
    output_file.write("Z\tN\tA\tl\tQ\tT_MR\n")

    # Read input values from the text file and process each line
    with open("input_values_MR.txt", "r") as input_file:
        for line in input_file:
            Z, N, A, l,  Q = map(float, line.split())
            formatted_Z = int(Z)
            formatted_N = int(N)
            formatted_A = int(A)
            formatted_l = int(l)
            formatted_Q = float(Q)
            a, b, c, d, e = determine_parameters(formatted_Z, formatted_N)
            T_MR = modified_royer(Z, N, A, Q, a, b, c, e, l)
            output_file.write(f"{formatted_Z}\t{formatted_N}\t{formatted_A}\t{formatted_l}\t{formatted_Q:.2f}\t{T_MR:.4f}\n")

#====================================================================================================#
# Display the result
print("Results have been saved to 'output_results_MR.txt'.")
#input("now press ENTER to exit")