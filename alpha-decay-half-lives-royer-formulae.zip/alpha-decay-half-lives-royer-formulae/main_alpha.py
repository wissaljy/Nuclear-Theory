# This script is to run alpha-decay formulae for multiple Royer formulae.
print("insert the symbol # in beginning if not wanting run all subprocess at once. \n"
      "edit the subprocess line in main_alpha.py.")
print("prepare the input files")
input("now press ENTER to run")
import subprocess

# insert "#" in beginning if not wanting to run all subprocess at once.
subprocess.run(["python", "Modified_RF.py"])
subprocess.run(["python", "Royer_Formulae.py"])

print("the calculations are successful and saved in output.txt")
#input("now press ENTER to exit")
