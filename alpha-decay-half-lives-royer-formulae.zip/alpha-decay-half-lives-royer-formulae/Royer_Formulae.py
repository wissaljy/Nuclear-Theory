import math

# G. Royer, J. Phys. G 26, 1149 (2000). # Royer Formula 1
# URL: https://iopscience.iop.org/article/10.1088/0954-3899/26/8/305
# A. Parkhomenko, A. Sobiczewski, Acta Phys. Pol. B 36, 3095 (2005).
# URL: https://www.actaphys.uj.edu.pl/R/36/10/3095/pdf
# D.T. Akrawy, H. Hassanabadi, S.S. Hosseini, K.P. Santhosh, Nucl. Phys. A 971, 130 (2018).
# https://doi.org/10.1016/j.nuclphysa.2018.01.018

#====================================================================================================#
# First sub-routine
# Function to calculate Royer Formula 1

def Royer_1(Z, A, Q, a, b, c):
    log_T = a * Z * Q**(-0.5) + b * A**(1/6) * Z**0.5 + c
    T_R1 = 10**log_T
    return log_T

def determine_a_b_c(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        a = 1.5864
        b = -1.1629
        c = -25.31
        return a, b, c
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        a = 1.5848
        b = -1.0859
        c = -26.65
        return a, b, c
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        a = 1.592
        b = -1.1423
        c = -25.68
        return a, b, c
    else:  # Both N and Z are odd
        a = 1.6971
        b = -1.113
        c = -29.48
        return a, b, c

# End of first sub-routine
#====================================================================================================#
# Second sub-routine
# Function to calculate Royer Formula 2

def Royer_2(Z, A, Q, a_2, b_2, c_2):
    log_Y = a_2 * Z * Q**(-0.5) + b_2 * A**(1/6) * Z**0.5 + c_2
    T_R2 = 10**log_Y
    return log_Y

def determine_a_2_b_2_c_2(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        a_2 = 1.5519
        b_2 = -0.9761
        c_2 = -28.688
        return a_2, b_2, c_2
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        a_2 = 1.6327
        b_2 = -1.1249
        c_2 = -27.287
        return a_2, b_2, c_2
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        a_2 = 1.607
        b_2 = -0.9467
        c_2 = -30.912
        return a_2, b_2, c_2
    else:  # Both N and Z are odd
        a_2 = 1.6789
        b_2 = -1.0409
        c_2 = -30.509
        return a_2, b_2, c_2

# End of second sub-routine
#====================================================================================================#
# Third sub-routine
# Function to calculate Royer Formula 3

def Royer_3(Z, A, Q, a_3, b_3, c_3):
    log_X = a_3 * Z * Q ** (-0.5) + b_3 * A ** (1 / 6) * Z ** 0.5 + c_3
    T_R3 = 10 ** log_X
    return log_X

def determine_a_3_b_3_c_3(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        a_3 = 1.58439
        b_3 = -1.15847
        c_3 = -25.319
        return a_3, b_3, c_3
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        a_3 = 1.72656
        b_3 = -1.0352
        c_3 = -31.9897
        return a_3, b_3, c_3
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        a_3 = 1.74562
        b_3 = -1.09816
        c_3 = -31.3906
        return a_3, b_3, c_3
    else:  # Both N and Z are odd
        a_3 = 1.70604
        b_3 = -1.10322
        c_3 = -27.5891
        return a_3, b_3, c_3

# End of third sub-routine
#====================================================================================================#
# Create and open an output text file for writing results
with open("output_results_RF.txt", "w") as output_file:
    output_file.write("Z\tN\tA\tQ\tT_R1\tT_R2\tT_R3\n")

    # Read input values from the text file and process each line
    with open("input_values.txt", "r") as input_file:
        for line in input_file:
            Z, N, A, Q = map(float, line.split())
            formatted_Z = int(Z)
            formatted_N = int(N)
            formatted_A = int(A)
            formatted_Q = float(Q)
            a, b, c = determine_a_b_c(formatted_Z, formatted_N)
            a_2, b_2, c_2 = determine_a_2_b_2_c_2(formatted_Z, formatted_N)
            a_3, b_3, c_3 = determine_a_3_b_3_c_3(formatted_Z, formatted_N)
            T_R1 = Royer_1(Z, A, Q, a, b, c)
            T_R2 = Royer_2(Z, A, Q, a_2, b_2, c_2)
            T_R3 = Royer_3(Z, A, Q, a_3, b_3, c_3)
            output_file.write(f"{formatted_Z}\t{formatted_N}\t{formatted_A}\t{formatted_Q:.2f}\t{T_R1:.4f}\t{T_R2:.4f}\t{T_R3:.4f}\n")

#====================================================================================================#
# Display the result
print("Results have been saved to 'output_results_RF.txt'.")
#input("now press ENTER to exit")