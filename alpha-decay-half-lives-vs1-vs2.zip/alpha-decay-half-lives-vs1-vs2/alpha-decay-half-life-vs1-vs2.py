import math

# To calculate alpha-decay half-lives via Viola-Seaborg Formula
# VSS1 paramters
# A. Sobiczewski, Z. Patyk, S. Cwiok, Phys. Lett. B 224, 1 (1989).  
# URL: https://doi.org/10.1016/0370-2693(89)91038-1
# VSS2 paramters
# A. Parkhomenko, A. Sobiczewski, Acta Phys. Pol. B 36, 3095 (2005).
# URL: https://www.actaphys.uj.edu.pl/R/36/10/3095/pdf

# Make sure the input_file have the interger values for Z, N, and Q 
#====================================================================================================#
# Begin subroutine 1
# Function to calculate half-life VSS1
def log_viola_seaborg_half_life(Z, Q, h_1):
    log_T_VSS1 = ((1.66175 * Z) + (-8.5166)) * (Q ** (-1 / 2)) + ((-0.20228) * Z) + (-33.9069) + (h_1)
    T_VSS1 = 10 ** (log_T_VSS1)
    return log_T_VSS1

# Determine the value of h_1 based on N and Z
def determine_h_1(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        return 0
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        return 1.066
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        return 0.772
    else:  # Both N and Z are odd
        return 1.114

# End of subroutine 1
#====================================================================================================#
# Begin subroutine 2

# Function to calculate half-life VSS2
def VSS_2(Z, Q, h_2):
    log_T_VSS2 = ((1.3892 * Z) + (13.862)) * (Q**(- 1/2)) + ((-0.1086) * Z) + (-41.458) + (h_2)
    T_VSS_2 = 10**(log_T_VSS2)
    return log_T_VSS2

# Determine the value of h_2 based on N and Z
def determine_h_2(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        return 0
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        return 0.641
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        return 0.437
    else:  # Both N and Z are odd
        return 1.024

#====================================================================================================#
# Create and open an output text file for writing results
with open("output_results_VS_formulae.txt", "w") as output_file:
    output_file.write("Z\tN\tQ\tlog_T_VSS1\tlog_T_VSS2\n")

    # Read input values from the text file and process each line
    with open("input_values.txt", "r") as input_file:
        for line in input_file:
            Z, N, Q = map(float, line.split())
            formatted_Z = int(Z)
            formatted_N = int(N)
            formatted_Q = float(Q)
            h_1 = determine_h_1(Z, N)
            h_2 = determine_h_2(Z, N)
            log_T_VSS1 = log_viola_seaborg_half_life(Z, Q, h_1)
            log_T_VSS2 = VSS_2(Z, Q, h_2)
            output_file.write(f"{formatted_Z}\t{formatted_N}\t{formatted_Q:.2f}\t{log_T_VSS1:.4f}\t{log_T_VSS2:.4f}\n")

#====================================================================================================#
# Display the result
print("Results have been saved to 'output_results_VS_formulae.txt'.")
input("now press ENTER to exit")

# End of program
#====================================================================================================#