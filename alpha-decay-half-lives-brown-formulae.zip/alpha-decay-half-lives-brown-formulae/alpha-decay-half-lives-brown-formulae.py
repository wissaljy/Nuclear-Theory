import math

# B.A. Brown, Phys. Rev. C 46, 811 (1992) # Brown Formula
# URL: https://doi.org/10.1103/PhysRevC.46.811
# I. Budaca, R. Budaca, I. Silisteanu, Nucl. Phys. A 951, 60 (2016). # Modified Brown 1 & 2
# URL: https://doi.org/10.1016/j.nuclphysa.2016.03.048

#====================================================================================================#
# First sub-routine
# Function to calculate Brown Formula
def brown_formula(Z, Q):
    log_T = (9.54) * (Z - 2)**(0.6) * (Q)**(-0.5) - 51.37
    T_BF = 10**(log_T)
    return log_T

# End of first sub-routine
#====================================================================================================#
# Second sub-routine
# Function to calculate Modified Brown Formula 1
def modified_brown(Z, Q, h_1):
    log_Y = (13.0707) * (Z - 2)**(0.5182) * (Q)**(-0.5) - 47.8867 + (h_1)
    T_MB1 = 10**(log_Y)
    return log_Y

# Determine the value of h_1 based on N and Z
def determine_h_1(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        return 0
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        return 0.4666
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        return 0.6001
    else:  # Both N and Z are odd
        return 0.82

# End of sub-routine 2
#====================================================================================================#
#  Function to calculate Modified Brown Formula 2
# third sub-routine
def modified_brown_2(Z, Q, a, b, c):
    log_Z = (a) * (Z - 2)**(b) * (Q)**(-0.5) - (c)
    T_MB2 = 10**(log_Z)
    return log_Z

# Determine the value of a,b,c, & d based on N and Z
def determine_a_b_c(Z, N):
    if Z % 2 == 0 and N % 2 == 0:  # Z and N are even
        a = 10.8238
        b = 0.5966
        c = 56.9785
        return a, b, c
    elif Z % 2 == 0 and N % 2 == 1:  # Z is even, N is odd
        a = 14.7747
        b = 0.5021
        c = 56.9785
        return a, b, c
    elif Z % 2 == 1 and N % 2 == 0:  # Z is odd, N is even
        a = 11.1462
        b = 0.5110
        c = 39.0096
        return a, b, c
    else:  # Both N and Z are odd
        a = 14.7405
        b = 0.4666
        c = 41.7227
        return a, b, c

# End of third sub-routine
#====================================================================================================#
# Create and open an output text file for writing results
with open("output_results_BF.txt", "w") as output_file:
    output_file.write("Z\tN\tQ\tT_BF\tT_MB1\tT_MB2\n")

    # Read input values from the text file and process each line
    with open("input_values.txt", "r") as input_file:
        for line in input_file:
            Z, N, Q = map(float, line.split())
            formatted_Z = int(Z)
            formatted_N = int(N)
            formatted_Q = float(Q)
            h_1 = determine_h_1(Z, N)
            T_BF = brown_formula(Z, Q)
            T_MB1 = modified_brown(Z, Q, h_1)
            a, b, c = determine_a_b_c(formatted_Z, formatted_N)
            T_MB2 = modified_brown_2(Z, Q, a, b, c)
            output_file.write(f"{formatted_Z}\t{formatted_N}\t{formatted_Q:.2f}\t{T_BF:.4f}\t{T_MB1:.4f}\t{T_MB2:.4f}\n")

#====================================================================================================#
# Display the result
print("Results have been saved to 'output_results_BF.txt'.")
input("now press ENTER to exit")